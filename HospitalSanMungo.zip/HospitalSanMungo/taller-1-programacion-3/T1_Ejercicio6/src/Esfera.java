public class Esfera {
    private int esfera;
    private String lugar;

    //constructor
    public Esfera(int esfera, String lugar) {
        this.esfera = esfera;
        this.lugar = lugar;
    }

    //getters

    public int getEsfera() {
        return esfera;
    }

    public String getLugar() {
        return lugar;
    }
}
